package luxe.chaos.chossserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChossServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChossServerApplication.class, args);
	}

}
